package myproject;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/InsertData")
public class InsertData extends HttpServlet {
    private static final String URL = "jdbc:mysql://localhost:3306/vehicleps"; // Change to your database URL
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       String Ownername = request.getParameter("Ownername");
        String Vehiclenumber = request.getParameter("Vehiclenumber");
        String Vehicletype = request.getParameter("Vehicletype");
        String Slot = request.getParameter("Slot");


        String sql = "INSERT INTO vehi_info (`Ownername`, `Vehiclenumber`, `Vehicletype`, `Slot`) VALUES (?, ?, ?, ?)";


        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, Ownername);
            pstmt.setString(2, Vehiclenumber);
            pstmt.setString(3, Vehicletype);
            pstmt.setString(4, Slot);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                response.getWriter().println("Vehicle parked successfully!");
            } else {
                response.getWriter().println("Failed to park vehicle.");
            }
        } catch (SQLException e) {
    e.printStackTrace();
    response.getWriter().println("Database error occurred: " + e.getMessage());
}

    }
}
