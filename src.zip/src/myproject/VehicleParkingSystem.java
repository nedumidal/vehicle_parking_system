package myproject; // Package declaration
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class VehicleParkingSystem {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/vehicle";
        String user = "root";
        String password = "";

        Scanner scanner = new Scanner(System.in);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure driver class is loaded

            try (Connection con = DriverManager.getConnection(url, user, password)) {
                System.out.print("Owner Name: ");
                String ownerName = scanner.nextLine();
                System.out.print("Vehicle Number: ");
                String vehicleNumber = scanner.nextLine();
                System.out.print("Vehicle Type: ");
                String vehicleType = scanner.nextLine();
                System.out.print("Parking Slot Number: ");
                String parkingSlotNumber = scanner.nextLine();

                String insertQuery = "INSERT INTO vehicle_info (Owner_Name, Vehicle_Number, Vehicle_Type, Parking_Slot_Number) VALUES (?, ?, ?, ?)";
                try (PreparedStatement pstmt = con.prepareStatement(insertQuery)) {
                    pstmt.setString(1, ownerName);
                    pstmt.setString(2, vehicleNumber);
                    pstmt.setString(3, vehicleType);
                    pstmt.setString(4, parkingSlotNumber);
                    pstmt.executeUpdate();
                    System.out.println("Data inserted successfully.");
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        scanner.close();
    }
}
